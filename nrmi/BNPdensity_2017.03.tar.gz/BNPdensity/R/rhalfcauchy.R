rhalfcauchy <-
function (n, location = 0, scale = 1) 
{
    abs(rcauchy(n, location, scale))
}
