rhalft <-
function (n, df = 1, mean = 0, sd = 1) 
{
    abs(rt_(n, df, mean, sd))
}
