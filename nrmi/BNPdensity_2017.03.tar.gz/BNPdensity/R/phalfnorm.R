phalfnorm <-
function (q, mean = 0, sd = 1) 
{
    ifelse(q < 0, 0, 1) * (pnorm(q, mean, sd) - pnorm(0, mean, 
        sd))/(1 - pnorm(0, mean, sd))
}
